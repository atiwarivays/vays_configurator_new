export const selectInstallationsortValues = (state) =>
  state.installationsortValues;
export const selectBauvorhabenValues = (state) => state.bauvorhabenValues;
export const selectBauphaseValues = (state) => state.bauphaseValues;
export const selectRaumeValues = (state) => state.raumeValues;
export const selectInstallationServiceValues = (state) =>
  state.installationServiceValues;
export const selectHeimautomatisierungValues = (state) =>
  state.heimautomatisierungValues;
export const selectVorhandenerValues = (state) => state.vorhandenerValues;
export const selectFordermittelserviceValues = (state) =>
  state.fordermittelserviceValues;
export const selectWartungsserviceValues = (state) =>
  state.wartungsServiceValues;
export const selectGewahrlewistungValues = (state) =>
  state.gewahrlewistungValues;
export const getBedienungSelection = (state) => state.bedienungSelection;
export const getFunctionSelection = (state) => state.functionSelection;
